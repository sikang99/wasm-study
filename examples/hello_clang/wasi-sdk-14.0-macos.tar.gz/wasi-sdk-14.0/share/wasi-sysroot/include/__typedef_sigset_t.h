#ifndef __wasilibc___typedef_sigset_t_h
#define __wasilibc___typedef_sigset_t_h

/* TODO: This is just a placeholder for now. Keep this in sync with musl. */
typedef unsigned char sigset_t;

#endif
